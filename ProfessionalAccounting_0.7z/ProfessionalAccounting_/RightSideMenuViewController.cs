using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    class RightSideMenuViewController : XDialogViewController
    {
        private abstract class BalancesTableViewDataSource
        {
            protected readonly string Path;
            protected readonly string[] Paths;

            public delegate void NavigateEventHandler(BalancesTableViewDataSource data);

            public event NavigateEventHandler NavigateTo;

            protected void InvokeNavigateTo(string path)
            {
                if (NavigateTo != null)
                    NavigateTo(CreateDataSource(path));
            }

            protected BalancesTableViewDataSource(string path)
            {
                Path = path;
                Paths = path.Split(new[] { '/' });
            }

            public static BalancesTableViewDataSource CreateDataSource(string path)
            {
                if (String.IsNullOrEmpty(path))
                    return new MainBalancesTableViewDataSource(path);
                var paths = path.Split(new[] {'/'});
                if (paths.Last().StartsWith("T"))
                    return new TitleBalancesTableViewDataSource(path);
                /*if (paths.Last().StartsWith("R"))
                    return new RemarkBalancesTableViewDataSource(path);*/
                return null;
            }

            public IEnumerable<Section> Data { get; protected set; }

            public virtual BalancesTableViewDataSource NavigateBack()
            {
                return CreateDataSource(Path.Substring(0, Path.Length - Paths.Last().Length - 1));
            }
        }

        private class MainBalancesTableViewDataSource : BalancesTableViewDataSource
        {
            public MainBalancesTableViewDataSource(string path) : base(path) { Data = LoadData(); }
            private IEnumerable<Section> LoadData()
            {
                var sec1 = new Section("��ݷ�ʽ");
                foreach (var shortcut in Application.BusinessHelper.SelectShortcuts())
                {
                    var item = shortcut;
                    var element = new StyledStringElement(
                        item.Name,
                        item.Balance.AsCurrency(),
                        UITableViewCellStyle.Subtitle);
                    element.Tapped += () => InvokeNavigateTo(Path + "/#/" + item.Path);
                    sec1.Add(element);
                }
                yield return sec1;

                var sec2 = new Section("�˻�");
                var tl = NSUserDefaults.StandardUserDefaults.IntForKey("mainTLevel");
                var titles = Application.BusinessHelper.SelectTitles(new DbTitle {TLevel = tl == 0 ? 0 : 1});
                if (tl == 2)
                    titles =
                        titles.Concat(Application.BusinessHelper.SelectTitles(new DbTitle {TLevel = 2}))
                              .OrderBy(t => t.ID);
                foreach (var t in titles)
                {
                    var item = t;
                    var element = new StyledStringElement(
                        String.Format("{0} {1}", item.ID.AsTitle(), item.Name),
                        Application.BusinessHelper.GetABalance(t).AsCurrency(),
                        UITableViewCellStyle.Subtitle);
                    element.Tapped += () => InvokeNavigateTo(Path + "/T" + item.ID.AsTitle());
                    sec2.Add(element);
                }
                yield return sec2;
            }
            
            public override BalancesTableViewDataSource NavigateBack() { return this; }
        }

        private class TitleBalancesTableViewDataSource : BalancesTableViewDataSource
        {
            public TitleBalancesTableViewDataSource(string path) : base(path) { Data = LoadData(); }
            private IEnumerable<Section> LoadData()
            {
                var title = new DbTitle { ID = Convert.ToDecimal(Paths.Last().Substring(1)) };
                title = Application.BusinessHelper.SelectTitles(title).Single();
                List<DbTitle> titles;
                Application.BusinessHelper.GetABalance(title, out titles, false);

                var sec0 = new Section(String.Format("{0} {1} {2}", title.ID.AsTitle(), title.Name, title.ABalance.AsCurrency()));
                yield return sec0;

                var sec1 = new Section(String.Format("���˻���{0}", title.Balance.AsCurrency()));
                foreach (var xBalance in Application.BusinessHelper.GetXBalances(title, false))
                {
                    var item = xBalance;
                    var element = new StyledStringElement(
                        item.Remark,
                        item.Fund.AsCurrency(),
                        UITableViewCellStyle.Subtitle);
                    element.Tapped += () => InvokeNavigateTo(Path + "/R" + item.Remark);
                    sec1.Add(element);
                }
                yield return sec1;

                var sec2 = new Section(String.Format("���˻���{0}", (title.ABalance - title.Balance).AsCurrency()));
                foreach (var t in titles)
                {
                    var item = t;
                    var element = new StyledStringElement(
                        String.Format("{0} {1}", item.ID.AsTitle(), item.Name),
                        t.ABalance.AsCurrency(),
                        UITableViewCellStyle.Subtitle);
                    element.Tapped += () => InvokeNavigateTo(Path + "/T" + item.ID.AsTitle());
                    sec2.Add(element);
                }
                yield return sec2;
            }
        }

        private BalancesTableViewDataSource m_DataSource;

        public RightSideMenuViewController()
            : base(UITableViewStyle.Plain, new RootElement(""))
        {
            HasNavigationBar = false;
            RefreshRequested += (sender, e) =>
            {
                DataSource = DataSource.NavigateBack();
                XReloadComplete();
            };
        }
        

        private BalancesTableViewDataSource DataSource
        {
            get
            {
                return m_DataSource;
            }
            set
            {
                if (m_DataSource != null)
                    m_DataSource.NavigateTo -= OnNavigate;
                m_DataSource = value;
                value.NavigateTo += OnNavigate;
                Root.Clear();
                foreach (var section in value.Data)
                    Root.Add(section);
            }
        }

        private void OnNavigate(BalancesTableViewDataSource data) { DataSource = data; }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            
            DataSource = BalancesTableViewDataSource.CreateDataSource("");
        }
    }
}