using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace ProfessionalAccounting
{
	partial class TitleToInsertCell : UITableViewCell
	{
		public TitleToInsertCell (System.IntPtr handle) : base (handle)
		{
		}
	}
}
