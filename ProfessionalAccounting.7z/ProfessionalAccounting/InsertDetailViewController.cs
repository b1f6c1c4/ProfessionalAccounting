using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace ProfessionalAccounting
{
	partial class InsertDetailViewController : UITableView
	{
		public InsertDetailViewController (System.IntPtr handle) : base (handle)
		{
		}
	}
}
