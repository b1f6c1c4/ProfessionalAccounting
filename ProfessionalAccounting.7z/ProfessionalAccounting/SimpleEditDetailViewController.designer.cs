// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace ProfessionalAccounting
{
	[Register ("SimpleEditDetailViewController")]
	partial class SimpleEditDetailViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UIButton DelButton { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField FundText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UIButton InsButton { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField ItemText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField RmkText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UILabel StatusLabel { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField TitleText { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (DelButton != null) {
				DelButton.Dispose ();
				DelButton = null;
			}
			if (FundText != null) {
				FundText.Dispose ();
				FundText = null;
			}
			if (InsButton != null) {
				InsButton.Dispose ();
				InsButton = null;
			}
			if (ItemText != null) {
				ItemText.Dispose ();
				ItemText = null;
			}
			if (RmkText != null) {
				RmkText.Dispose ();
				RmkText = null;
			}
			if (StatusLabel != null) {
				StatusLabel.Dispose ();
				StatusLabel = null;
			}
			if (TitleText != null) {
				TitleText.Dispose ();
				TitleText = null;
			}
		}
	}
}
