using System;
using System.Collections.Generic;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    sealed partial class ItemDetailCell : UITableViewCell
	{
	    private UILabel ItemLabel;
        private List<UILabel> DetaiLabels;

	    public ItemDetailCell(string cellID) : base(UITableViewCellStyle.Default, cellID)
        {
            ItemLabel = new UILabel
            {
                Font = UIFont.FromName("Heiti SC", 22f),
                BackgroundColor = UIColor.Clear
            };

            ContentView.Add(ItemLabel);
	    }

        public void SetText(DbItem entity, IEnumerable<DbDetail> entities)
        {
            ItemLabel.Text = String.Format("{0} {1} {2}", entity.GetIDText(), entity.GetDTText(), entity.Remark);

            DetaiLabels=new List<UILabel>();
            foreach (var detail in entities)
            {
                var lbl = new UILabel
                              {
                                  Font = UIFont.FromName("Heiti SC", 15f),
                                  BackgroundColor = UIColor.Clear,
                                  Text =
                                      String.Format(
                                                    "{0} {1} {2}",
                                                    detail.GetTitleText(),
                                                    detail.Remark,
                                                    detail.GetFundText())
                              };
                DetaiLabels.Add(lbl);
                ContentView.Add(lbl);
            }
        }

        public override void LayoutSubviews()
        {
            base.LayoutSubviews();
            ItemLabel.Frame=new RectangleF(0,0,200,20);
            for (var i = 0; i < DetaiLabels.Count; i++)
            {
                DetaiLabels[i].Frame = new RectangleF(0, 20 * (i + 1), 200, 20);
            }
            Frame = new RectangleF(Frame.X, Frame.Y, 200, DetaiLabels.Count * 20 + 20);
        }
	}
}
