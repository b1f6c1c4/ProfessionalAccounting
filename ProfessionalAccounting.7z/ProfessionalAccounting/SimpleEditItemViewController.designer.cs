// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace ProfessionalAccounting
{
	[Register ("SimpleEditItemViewController")]
	partial class SimpleEditItemViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UIButton DelButton { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField DTText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField IDText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UIButton InsButton { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField RmkText { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UILabel StatusLabel { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (DelButton != null) {
				DelButton.Dispose ();
				DelButton = null;
			}
			if (DTText != null) {
				DTText.Dispose ();
				DTText = null;
			}
			if (IDText != null) {
				IDText.Dispose ();
				IDText = null;
			}
			if (InsButton != null) {
				InsButton.Dispose ();
				InsButton = null;
			}
			if (RmkText != null) {
				RmkText.Dispose ();
				RmkText = null;
			}
			if (StatusLabel != null) {
				StatusLabel.Dispose ();
				StatusLabel = null;
			}
		}
	}
}
