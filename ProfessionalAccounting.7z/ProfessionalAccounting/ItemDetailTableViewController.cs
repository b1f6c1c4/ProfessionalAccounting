using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
	partial class ItemDetailTableViewController : UITableViewController
	{
	    private List<DbItem> lst1;
        private List<List<DbDetail>> lst2;

		public ItemDetailTableViewController (System.IntPtr handle) : base (handle)
		{
        }

	    public override float GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
	    {
	        //return lst2[indexPath.Row].Count() * 20 + 20;
	        return tableView.CellAt(indexPath).Frame.Height;
	    }

	    public override void DidReceiveMemoryWarning()
        {
            // Releases the view if it doesn't have a superview.
            base.DidReceiveMemoryWarning();

            // Release any cached data, images, etc that aren't in use.
        }

        #region View lifecycle

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            // Perform any additional setup after loading the view, typically from a nib.
            lst1 = Application.BusinessHelper.SelectItems(new DbItem()).ToList();
            lst2 = lst1.Select(entity => Application.BusinessHelper.SelectDetails(entity).ToList()).ToList();
            ItemDetailTable.Source=new ItemDetailTableSource(lst1,lst2);
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);
        }

        #endregion
	}
}
