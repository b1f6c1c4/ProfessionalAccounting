// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace ProfessionalAccounting
{
	[Register ("ProfessionalAccountingViewController")]
	partial class ProfessionalAccountingViewController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UILabel ConnStatusLabel { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UIButton CreateDbButton { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		MonoTouch.UIKit.UITextField IDText { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (ConnStatusLabel != null) {
				ConnStatusLabel.Dispose ();
				ConnStatusLabel = null;
			}
			if (CreateDbButton != null) {
				CreateDbButton.Dispose ();
				CreateDbButton = null;
			}
			if (IDText != null) {
				IDText.Dispose ();
				IDText = null;
			}
		}
	}
}
