using System;
using System.Drawing;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
	partial class SimpleEditItemViewController : UIViewController
	{
		public SimpleEditItemViewController (System.IntPtr handle) : base (handle)
		{
        }
        public override void DidReceiveMemoryWarning()
        {
            // Releases the view if it doesn't have a superview.
            base.DidReceiveMemoryWarning();

            // Release any cached data, images, etc that aren't in use.
        }


	    private DbItem ParseDbItem()
        {
            var entity = new DbItem();
            entity.SetIDText(IDText.Text);
            entity.SetDTText(DTText.Text);
            entity.SetRemarkText(RmkText.Text);
	        return entity;
	    }

	    private void ShowDbItem(DbItem entity)
	    {
	        IDText.Text = entity.GetIDText();
	        DTText.Text = entity.GetDTText();
	        RmkText.Text = entity.Remark;
	    }

        #region View lifecycle

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            // Perform any additional setup after loading the view, typically from a nib.
            ShowDbItem(new DbItem());

            Action<UIControl> setFrame = ui => ui.Frame = new RectangleF(ui.Frame.X, ui.Frame.Y, 100, ui.Frame.Height);
            setFrame(IDText);
            setFrame(DTText);
            setFrame(RmkText);

            InsButton.TouchUpInside += (sender, e) =>
                                       {
                                           try
                                           {
                                               var entity = ParseDbItem();
                                               Application.BusinessHelper.InsertItem(entity);
                                               ShowDbItem(entity);
                                               StatusLabel.Text = "Succeed";
                                           }
                                           catch (Exception exception)
                                           {
                                               StatusLabel.Text = "Failed:" + exception.ToString();
                                           }
                                       };
            DelButton.TouchUpInside += (sender, e) =>
                                       {
                                           try
                                           {
                                               var l = Application.BusinessHelper.DeleteItems(ParseDbItem());
                                               StatusLabel.Text = String.Format("Deleted Items:{0:0}", l);
                                           }
                                           catch (Exception exception)
                                           {
                                               Console.WriteLine(exception);
                                           }
                                       };
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
        }

        public override void ViewDidDisappear(bool animated)
        {
            base.ViewDidDisappear(animated);
        }

        #endregion
	}
}
