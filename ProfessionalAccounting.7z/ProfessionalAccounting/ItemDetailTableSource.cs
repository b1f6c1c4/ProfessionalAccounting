using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    class ItemDetailTableSource : UITableViewSource
    {
        private readonly List<DbItem> m_Items;
        private readonly List<List<DbDetail>> m_Details;
        private const string Ident = "ItemDetail";

        public ItemDetailTableSource(List<DbItem> items, List<List<DbDetail>> detail)
        {
            m_Items = items;
            m_Details = detail;
        }

        public override int NumberOfSections(UITableView tableView) { return m_Items.Count; }

        public override int RowsInSection(UITableView tableView, int section) { return m_Details[section].Count; }

        public override string TitleForHeader(UITableView tableView, int section)
        {
            return m_Items[section].GetFullText();
        }
        
        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = tableView.DequeueReusableCell(Ident) ?? new UITableViewCell(UITableViewCellStyle.Subtitle, Ident);
            var detail = m_Details[indexPath.Section][indexPath.Row];
            cell.TextLabel.Text = detail.GetSemiFullText();
            cell.DetailTextLabel.Text = Application.BusinessHelper.GetTitleName(detail);
            return cell;
        }
    }
}