using System;
using System.Drawing;
using System.Text;
using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    class ItemsViewController : XDialogViewController
    {
        private readonly DbItem m_Item;
        private readonly DbDetail m_Detail;
        private readonly Section m_ParentSection;

        private new void ReloadComplete()
        {
            base.XReloadComplete();
        }

        public override RefreshTableHeaderView MakeRefreshTableHeaderView(RectangleF rect) { return new ReturnRefreshView(rect); }

        public ItemsViewController()
            : base(new RootElement(NSUserDefaults.StandardUserDefaults.StringForKey("dbName")))
        {
            Autorotate = true;
            HasNavigationBar = true;
            RefreshRequested += (sender, e) =>
            {
                Root.Clear();
                GetData(Root);
                ReloadComplete();
            };
        }

        public ItemsViewController(RootElement root, DbItem item, Section parentSection)
            : base(root,true)
        {
            Autorotate = true;
            HasNavigationBar = true;
            m_Item = item;
            m_ParentSection = parentSection;
            RefreshRequested += (sender, e) =>
                                {
                                    NavigationController.PopViewControllerAnimated(true);
                                    ReloadComplete();
                                };
        }
        public ItemsViewController(RootElement root, DbDetail detail, Section parentSection)
            : base(root,true)
        {
            Autorotate = true;
            HasNavigationBar = true;
            m_Detail = detail;
            m_ParentSection = parentSection;
            RefreshRequested += (sender, e) =>
                                {
                                    NavigationController.PopViewControllerAnimated(true);
                                    ReloadComplete();
                                };
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            if (m_Item != null)
            {
                NavigationItem.SetRightBarButtonItem(
                                                     new UIBarButtonItem(
                                                         "+",
                                                         UIBarButtonItemStyle.Bordered,
                                                         (sender, e) =>
                                                         {
                                                             var detail = new DbDetail { Item = m_Item.ID };
                                                             var el = CreateElement(detail, Root[0]);
                                                             NavigationController.PushViewController(
                                                                                                     new ItemsViewController(
                                                                                                         el,
                                                                                                         detail,
                                                                                                         Root[0]),
                                                                                                     true);
                                                         }),
                                                     false);
                return;
            }
            if (m_Detail != null)
                return;

            GetData(Root);
            NavigationItem.SetRightBarButtonItem(
                                                 new UIBarButtonItem(
                                                     "+",
                                                     UIBarButtonItemStyle.Bordered,
                                                     (sender, e) =>
                                                     {
                                                         var item = new DbItem { DT = DateTime.Now.Date };
                                                         //Application.BusinessHelper.InsertItem(item);
                                                         //GetData();
                                                         NavigationController.PushViewController(
                                                                                                 new ItemsViewController
                                                                                                     (
                                                                                                     CreateElement(
                                                                                                                   item,
                                                                                                                   Root[
                                                                                                                        0
                                                                                                                       ]),
                                                                                                     item,
                                                                                                     Root[0]),
                                                                                                 true);
                                                     }),
                                                 false);
        }
        
        private void GetData(RootElement r)
        {
            var items = Application.BusinessHelper.SelectItems(new DbItem());
            Section sec = null;
            DateTime? dt = null;
            foreach (var item in items)
            {
                if (sec == null)
                {
                    sec = new Section();
                    dt = item.DT;
                }
                else if (dt != item.DT)
                {
                    sec.Caption = dt.AsDT();
                    r.Insert(0, sec);
                    sec = new Section();
                    dt = item.DT;
                }
                sec.Add(CreateElement(item));
            }
            if (sec != null)
            {
                sec.Caption = dt.AsDT();
                r.Insert(0, sec);
            }
            var secNew = new Section();
            r.Insert(0, secNew);
        }

        private RootElement CreateElement(DbItem item, Section itemsSection = null)
        {
            var noDate = new BooleanElement("������", !item.DT.HasValue);

            Element idElement;
            if (itemsSection != null)
                idElement = new EntryElement("ID", "��������������ĩ", item.ID.AsID())
                                {
                                    KeyboardType =
                                        UIKeyboardType.NumberPad,
                                };
            else
                idElement = new StringElement("ID", item.ID.AsID());
            var basic = new Section("������Ϣ")
                              {
                                  idElement,
                                  noDate
                              };
            var date = new CustomDateElement("����", item.DT ?? DateTime.Now);
            if (item.DT.HasValue)
                basic.Add(date);

            var rmkElement = new EntryElement("��ע", "�ޱ�ע", item.Remark);
            basic.Add(rmkElement);
            
            noDate.ValueChanged += (sender, e) =>
                                    {
                                        if (noDate.Value)
                                            basic.Remove(date);
                                        else
                                            basic.Insert(2, date);
                                    };


            var details = new Section("��ϸ");

            var r = new RootElement(GetCaption(item))
                        {
                            details
                        };
            r.createOnSelected = e => new ItemsViewController(e, item, itemsSection);

            Func<Section> getOp = () =>
                                  new Section("����")
                                      {
                                          new ButtonElement(
                                              "����",
                                              () =>
                                              {
                                                  Application.BusinessHelper.DeleteItems(item);

                                                  if (!noDate.Value)
                                                      item.DT = date.DateValue.ToLocalTime();
                                                  else
                                                      item.DT = null;
                                                  item.SetRemarkText(rmkElement.Value);
                                                  Application.BusinessHelper.InsertItem(item);

                                                  r.Caption = GetCaption(item);
                                                  Title = r.Caption;
                                              }),
                                          new ButtonElement(
                                              "�޸�ID",
                                              () =>
                                              {
                                                  //TODO:�޸�Item��ID
                                              }),
                                          new ButtonElement(
                                              "ɾ��",
                                              () =>
                                              {
                                                  var cnt =
                                                      Application.BusinessHelper.SelectItemsCount(
                                                                                                  new DbItem
                                                                                                      {
                                                                                                          ID =
                                                                                                              item
                                                                                                              .ID
                                                                                                      });
                                                  var v = new UIAlertView(
                                                      "ɾ��",
                                                      String.Format("��ȷ��ɾ��{0}����¼��", cnt),
                                                      null,
                                                      "ȡ��",
                                                      new[] {"ȷ��"});
                                                  v.Clicked += (sender, e) =>
                                                               {
                                                                   if (e.ButtonIndex == 1)
                                                                   {
                                                                       Application.BusinessHelper.DeleteItems(item);
                                                                       var section = r.Parent as Section;
                                                                       if (section != null)
                                                                           section.Remove(r);
                                                                       NavigationController.PopViewControllerAnimated(true);
                                                                   }
                                                               };
                                                  v.Show();
                                              }),
                                      };



            if (itemsSection != null)
            {
                r.Add(
                      new Section("����")
                          {
                              new ButtonElement(
                                  "����/����",
                                  () =>
                                  {
                                      // ReSharper disable once PossibleNullReferenceException
                                      item.SetIDText((idElement as EntryElement).Value);
                                      if (!noDate.Value)
                                          item.DT = date.DateValue.ToLocalTime();
                                      else
                                          item.DT = null;
                                      item.SetRemarkText(rmkElement.Value);
                                      Application.BusinessHelper.InsertItem(item);
                                      r.Caption = GetCaption(item);

                                      itemsSection.Add(r);

                                      basic.Remove(0);
                                      idElement = new StringElement("ID", item.ID.AsID());
                                      basic.Insert(0, idElement);
                                      r.RemoveAt(1);
                                      r.Insert(1,getOp());
                                  })
                          });
            }
            else
            {
                foreach (var detail in Application.BusinessHelper.SelectDetails(item))
                    details.Add(CreateElement(detail));
                r.Add(getOp());
            }

            r.Add(basic);

            return r;
        }

        private static string GetCaption(DbItem item)
        {
            var sbPos = new StringBuilder();
            var sbNeg = new StringBuilder();

            var pos = (decimal)0;
            var neg = (decimal)0;
            var cntPos = 0;
            var cntNeg = 0;
            foreach (var detail in Application.BusinessHelper.SelectDetails(item))
            {
                if (!detail.Fund.HasValue)
                    continue;
                if (detail.Fund > 0)
                {
                    pos += detail.Fund.Value;
                    switch (cntPos)
                    {
                        case 2:
                            sbPos.Append("..");
                            cntPos++;
                            break;
                        case 3:
                            break;
                        default:
                            cntPos++;
                            if (String.IsNullOrEmpty(detail.Remark))
                                sbPos.AppendFormat(
                                                   "{0} ",
                                                   Application.BusinessHelper.GetTitleName(detail.Title).Restriction(1));
                            else
                                sbPos.AppendFormat(
                                                   "{0}[{1}]",
                                                   Application.BusinessHelper.GetTitleName(detail.Title).Restriction(1),
                                                   detail.Remark.Restriction(4));
                            break;
                    }
                }
                else if (detail.Fund < 0)
                {
                    neg -= detail.Fund.Value;
                    switch (cntNeg)
                    {
                        case 2:
                            sbNeg.Append("..");
                            cntNeg++;
                            break;
                        case 3:
                            break;
                        default:
                            cntNeg++;
                            if (String.IsNullOrEmpty(detail.Remark))
                                sbNeg.AppendFormat(
                                                   "{0} ",
                                                   Application.BusinessHelper.GetTitleName(detail.Title).Restriction(1));
                            else
                                sbNeg.AppendFormat(
                                                   "{0}[{1}]",
                                                   Application.BusinessHelper.GetTitleName(detail.Title).Restriction(1),
                                                   detail.Remark.Restriction(4));
                            break;
                    }
                }
            }
            if (pos != neg)
                sbPos.Insert(0, pos);

            sbNeg.Insert(0, String.Format("{0}# {1} ", item.ID.AsID(), neg));

            sbNeg.Append("->");
            sbNeg.Append(sbPos);

            return sbNeg.ToString();
        }

        private RootElement CreateElement(DbDetail detail, Section detailsSection = null)
        {
            var titleElement = new EntryElement("��Ŀ", "��д��Ŀ����", detail.Title.AsTitle())
                                   {
                                       KeyboardType = UIKeyboardType.NumbersAndPunctuation
                                   };
            var titleName = new StyledStringElement(Application.BusinessHelper.GetTitleName(detail.Title))
                                {
                                    TextColor = UIColor.Gray
                                };
            titleElement.Changed += (sender, e) =>
                                    {
                                        Decimal t;
                                        if (Decimal.TryParse(titleElement.Value, out t))
                                            titleName.Value = Application.BusinessHelper.GetTitleName(t);
                                    };
            var fundElement = new EntryElement("����", "�����Ԫ", detail.Fund.AsPureCurrency())
                                  {
                                      KeyboardType = UIKeyboardType.NumbersAndPunctuation
                                  };
            var rmkElement = new EntryElement("��ע", "��������Ŀ", detail.Remark)
                                 {
                                     KeyboardType = UIKeyboardType.Default,
                                     ReturnKeyType = UIReturnKeyType.Done
                                 };
            rmkElement.ShouldReturn += () =>
                                       {
                                           rmkElement.ResignFirstResponder(true);
                                           return true;
                                       };
            var r = new RootElement(GetCaption(detail))
                        {
                            new Section
                                {
                                    titleElement,
                                    fundElement,
                                    rmkElement
                                }
                        };
            r.createOnSelected = e => new ItemsViewController(e, detail, detailsSection);

            var randomElement = new ButtonElement(
                "�������Ψһ��ʶ��",
                () => rmkElement.Value = Application.BusinessHelper.GenerateUniqueIdentifier());
            if (detailsSection != null)
            {
                r.Add(
                      new Section("����")
                          {
                              new ButtonElement(
                                  "����",
                                  () =>
                                  {
                                      var entity = new DbDetail {Item = detail.Item};
                                      entity.SetTitleText(titleElement.Value);
                                      entity.SetFundText(fundElement.Value);
                                      entity.SetRemarkText(rmkElement.Value);
                                      Application.BusinessHelper.InsertDetail(entity);

                                      detailsSection.Insert(0, CreateElement(entity));
                                      NavigationController.PopViewControllerAnimated(true);
                                  }),
                              randomElement
                          });
            }
            else
            {
                r.Add(
                      new Section("����")
                          {
                              new ButtonElement(
                                  "����",
                                  () =>
                                  {
                                      var cnt = Application.BusinessHelper.SelectDetailsCount(detail);
                                      var entity = new DbDetail {Item = detail.Item};
                                      entity.SetTitleText(titleElement.Value);
                                      entity.SetFundText(fundElement.Value);
                                      entity.SetRemarkText(rmkElement.Value);

                                      switch (cnt)
                                      {
                                          case 0:
                                              (new UIAlertView("����", "û����ؼ�¼��", null, "ȷ��", null)).Show();
                                              break;
                                          case 1:
                                              Application.BusinessHelper.DeleteDetails(detail);
                                              Application.BusinessHelper.InsertDetail(entity);
                                              break;
                                          default:
                                              {
                                                  var v = new UIAlertView(
                                                      "����",
                                                      String.Format("��ȷ�ϸ�����ȫ��ͬ��{0}����¼��", cnt),
                                                      null,
                                                      "ȡ��",
                                                      new[] {"����ȫ��"});
                                                  v.Clicked += (sender, e) =>
                                                               {
                                                                   if (e.ButtonIndex == 1)
                                                                   {
                                                                       Application.BusinessHelper.DeleteDetails(detail);
                                                                       Application.BusinessHelper.InsertDetail(entity);
                                                                   }
                                                               };
                                                  v.Show();
                                              }
                                              break;
                                      }
                                      r.Caption = GetCaption(entity);
                                  }),
                              new ButtonElement(
                                  "ɾ��",
                                  () =>
                                  {
                                      var cnt = Application.BusinessHelper.SelectDetailsCount(detail);
                                      switch (cnt)
                                      {
                                          case 0:
                                              (new UIAlertView("ɾ��", "û����ؼ�¼��", null, "ȷ��", null)).Show();
                                              break;
                                          case 1:
                                              Application.BusinessHelper.DeleteDetails(detail);
                                              var section = r.Parent as Section;
                                              if (section != null)
                                                  section.Remove(r);
                                              NavigationController.PopViewControllerAnimated(true);
                                              break;
                                          default:
                                              {
                                                  var v = new UIAlertView(
                                                      "ɾ��",
                                                      String.Format("��ȷ��ɾ����ȫ��ͬ��{0}����ϸ��", cnt),
                                                      null,
                                                      "ȡ��",
                                                      new[] {"ɾ��ȫ��"});
                                                  v.Clicked += (sender, e) =>
                                                               {
                                                                   if (e.ButtonIndex == 1)
                                                                   {
                                                                       Application.BusinessHelper.DeleteDetails(detail);
                                                                       NavigationController.PopViewControllerAnimated(
                                                                                                                      true);
                                                                   }
                                                               };
                                                  v.Show();
                                              }
                                              break;
                                      }
                                  }),
                              new ButtonElement(
                                  "�ۺ�ɾ��",
                                  () =>
                                  {
                                      var entity = new DbDetail {Item = detail.Item};
                                      entity.SetTitleText(titleElement.Value);
                                      entity.SetFundText(fundElement.Value);
                                      entity.SetRemarkText(rmkElement.Value);
                                      var cnt = Application.BusinessHelper.SelectDetailsCount(entity);
                                      switch (cnt)
                                      {
                                          case 0:
                                              (new UIAlertView("ɾ��", "û����ؼ�¼��", null, "ȷ��", null)).Show();
                                              break;
                                          case 1:
                                              Application.BusinessHelper.DeleteDetails(entity);
                                              break;
                                          default:
                                              {
                                                  var v = new UIAlertView(
                                                      "ɾ��",
                                                      String.Format("��ȷ��ɾ��{0}����ϸ��", cnt),
                                                      null,
                                                      "ȡ��",
                                                      new[] {"ɾ��ȫ��"});
                                                  v.Clicked += (sender, e) =>
                                                               {
                                                                   if (e.ButtonIndex == 1)
                                                                       Application.BusinessHelper.DeleteDetails(entity);
                                                               };
                                                  v.Show();
                                              }
                                              break;
                                      }
                                  }),
                              randomElement,
                              new ButtonElement(
                                  "�޸�ID",
                                  () =>
                                  {
                                      //TODO:�޸�Detail��ID 
                                  })
                          });
            }
            return r;
        }

        private static string GetCaption(DbDetail detail)
        {
            return String.Format(
                                 "{0} {1} {2} {3}",
                                 detail.Title.AsTitle(),
                                 Application.BusinessHelper.GetTitleName(detail.Title),
                                 detail.Remark,
                                 detail.Fund.AsCurrency());
        }
    }
}