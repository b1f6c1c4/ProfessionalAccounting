using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace ProfessionalAccounting
{
    class SettingsViewController : DialogViewController
    {
        public SettingsViewController() : base(UITableViewStyle.Grouped, new RootElement("")) { }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            var dbName = new EntryElement("�˱���", "", NSUserDefaults.StandardUserDefaults.StringForKey("dbName"));

            var reConnect = new ButtonElement(
                "����/���¼���",
                () =>
                {
                    NSUserDefaults.StandardUserDefaults.SetString(dbName.Value, "dbName");
                    Application.BusinessHelper.Connect(dbName.Value);
                });

            /*var init = new ButtonElement(
                "�´�������ʾ������Ļ",
                () => NSUserDefaults.StandardUserDefaults.SetBool(false, "everLaunched"));*/

            /*var carryInterval = new RadioGroup("���", NSUserDefaults.StandardUserDefaults.IntForKey("carryInterval"));
            NSAction changeCarryInterval = () => NSUserDefaults.StandardUserDefaults.SetInt(carryInterval.Selected, "carryInterval");*/

            var editTitles = new ButtonElement("�л��༭����", null);
            var boolEditing = false;
            editTitles.Tapped += () =>
                       {
                           if (boolEditing)
                           {
                               while (
                                   Application.Container.TopNavigation.PopViewControllerAnimated(false) is
                                   TitlesViewController) { }
                               Application.Container.Hide();
                           }
                           else
                           {
                               Application.Container.TopNavigation.PushViewController(
                                                                                      new TitlesViewController(),
                                                                                      false);
                               Application.Container.Hide();
                           }
                           boolEditing ^= true;
                       };

            Root.Add(
                     new Section("��������")
                         {
                             dbName,
                             reConnect,
                             //init,
                             /*new RootElement("��ת���۾�", carryInterval)
                                 {
                                     new Section()
                                 },*/
                             editTitles
                         });

            /*var depMethod = new RadioGroup("����", NSUserDefaults.StandardUserDefaults.IntForKey("depMethod"));
            NSAction changeDepMathod = () => NSUserDefaults.StandardUserDefaults.SetInt(depMethod.Selected, "depMethod");
            var depMathodLinear = new RadioElement("ֱ�߷�", depMethod.Key);
            depMathodLinear.Tapped += changeDepMathod;
            var depMathodDouble = new RadioElement("˫�����ݼ���", depMethod.Key);
            depMathodDouble.Tapped += changeDepMathod;
            var depMathodSquare = new RadioElement("�����ܺͷ�", depMethod.Key);
            depMathodSquare.Tapped += changeDepMathod;

            Root.Add(
                     new Section("�̶��ʲ�")
                         {
                             new ButtonElement("�鿴",
                                               () =>
                                               {
                                                   Application.Container.TopNavigation.PushViewController(
                                                                                                          new FixedAssetsViewController
                                                                                                              (),
                                                                                                          true);
                                               }),
                             new RootElement("����",depMethod)
                                 {
                                     new Section("�۾ɷ���")
                                         {
                                             depMathodLinear,
                                             depMathodDouble,
                                             depMathodSquare
                                         }
                                 }
                         });

            var mainTLevel = new RadioGroup("���", NSUserDefaults.StandardUserDefaults.IntForKey("mainTLevel"));
            NSAction changeMainTLevel =
                () => NSUserDefaults.StandardUserDefaults.SetInt(mainTLevel.Selected, "mainTLevel");
            var mainTLevel0 = new RadioElement("0����Ŀ", mainTLevel.Key);
            mainTLevel0.Tapped += changeMainTLevel;
            var mainTLevel1 = new RadioElement("1����Ŀ", mainTLevel.Key);
            mainTLevel1.Tapped += changeMainTLevel;
            var mainTLevel2 = new RadioElement("2����Ŀ", mainTLevel.Key);
            mainTLevel2.Tapped += changeMainTLevel;

            Root.Add(
                     new Section("��ʾ")
                         {
                             new RootElement("��Ŀ", new RadioGroup("��Ŀ", 0))
                                 {
                                     new Section
                                         {
                                             new RadioElement("1��", "��Ŀ"),
                                             new RadioElement("7��", "��Ŀ"),
                                             new RadioElement("����", "��Ŀ"),
                                             new RadioElement("����", "��Ŀ")
                                         }
                                 },
                             new RootElement("���", mainTLevel)
                                 {
                                     new Section("��ݷ�ʽ"),
                                     new Section("��ҳ��Ŀ")
                                         {
                                             mainTLevel0,
                                             mainTLevel1,
                                             mainTLevel2
                                         }
                                 }
                         });*/

        }
    }
}