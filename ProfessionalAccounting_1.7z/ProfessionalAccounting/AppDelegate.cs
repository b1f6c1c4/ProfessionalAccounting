﻿using System;
using System.Drawing;

using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;

namespace ProfessionalAccounting
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the 
    // User Interface of the application, as well as listening (and optionally responding) to 
    // application events from iOS.
    [Register("AppDelegate")]
    public class AppDelegate : UIApplicationDelegate
    {
        // class-level declarations
        UIWindow window;

        //
        // This method is invoked when the application has loaded and is ready to run. In this 
        // method you should instantiate the window, load the UI into it and then make the window
        // visible.
        //
        // You have 17 seconds to return from this method, or iOS will terminate your application.
        //
        public override bool FinishedLaunching(UIApplication app, NSDictionary options)
        {
            // create a new window instance based on the screen size
            var w = UIScreen.MainScreen.Bounds.Width;
            var h = UIScreen.MainScreen.Bounds.Height;

            window = new UIWindow(new RectangleF(0, 0, w, h));

            // If you have defined a view, add it here:

            Application.BusinessHelper = new BHelper();

            var first = !NSUserDefaults.StandardUserDefaults.BoolForKey("everLaunched");
            if (first)
            {
                var scrollView = new UIScrollView(new RectangleF(0, 0, w, h))
                {
                    PagingEnabled = true,
                    Bounces = false,
                    ContentSize = new SizeF(3 * w, 0),
                    ShowsHorizontalScrollIndicator = false,
                    ShowsVerticalScrollIndicator = false,
                    ScrollsToTop = false
                };
                var pageControl = new UIPageControl(new RectangleF(0, h-70, w, 70))
                {
                    Pages = 3,
                    CurrentPage = 0
                };
                var lastPage = new UIView
                {
                    BackgroundColor = UIColor.Yellow,
                    Frame = new RectangleF(2 * w, 0, w, h),
                    UserInteractionEnabled = true
                };
                var btn = new UIButton(UIButtonType.Custom) { Frame = new RectangleF(0, 0, w / 2, h / 3) };
                btn.SetTitle(null, UIControlState.Normal);
                lastPage.AddSubview(btn);
                scrollView.AddSubviews(
                                       new UIView
                                       {
                                           BackgroundColor = UIColor.Purple,
                                           Frame = new RectangleF(0, 0, w, h)
                                       },
                                       new UIView
                                       {
                                           BackgroundColor = UIColor.Orange,
                                           Frame = new RectangleF(w, 0, w, h)
                                       },
                                       lastPage);
                var controller = new UIViewController();
                controller.View.AddSubviews(scrollView, pageControl);
                controller.View.BringSubviewToFront(pageControl);
                scrollView.Scrolled += (sender, e) =>
                {
                    var pg = (int)((scrollView.ContentOffset.X) / w + 0.5f);
                    pageControl.CurrentPage = pg;
                };
                btn.TouchUpInside += (sender, e) =>
                {
                    CreateUI();
                    controller.PresentViewController(Application.Container, true, null);
                };
                window.RootViewController = controller;
                NSUserDefaults.StandardUserDefaults.SetString("默认", "dbName");
                NSUserDefaults.StandardUserDefaults.SetInt(2, "mainTLevel");
                NSUserDefaults.StandardUserDefaults.SetInt(0, "depMethod");
                NSUserDefaults.StandardUserDefaults.SetBool(true, "everLaunched");
            }
            else
            {
                CreateUI();
                window.RootViewController = Application.Container;
            }

            // make the window visible
            window.MakeKeyAndVisible();

            return true;
        }

        private static void CreateUI()
        {
            try
            {
                Application.BusinessHelper.Connect(NSUserDefaults.StandardUserDefaults.StringForKey("dbName"));
                var leftSideMenuController = new SettingsViewController();
                var rightSideMenuController = new RightSideMenuViewController();

                Application.Container = new SlideoutNavigationController
                {
                    SlideHeight = 9999f,
                    TopView = new ItemsViewController(),
                    MenuViewLeft = leftSideMenuController,
                    MenuViewRight = rightSideMenuController,
                    DisplayNavigationBarCenteral = true,
                    DisplayNavigationBarOnLeftMenu = false,
                    DisplayNavigationBarOnRightMenu = false,
                    LeftMenuButtonText = null,
                    RightMenuButtonText = null
                };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}