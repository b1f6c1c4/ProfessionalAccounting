using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    class TitlesViewController : XDialogViewController
    {
        public TitlesViewController()
            : base(new RootElement("��Ŀ���ݷ�ʽ"))
        {
            Autorotate = true;
            HasNavigationBar = true;
            RefreshRequested += (sender, e) =>
            {
                Root.Clear();
                LoadData(Root);
                ReloadComplete();
            };
            LoadData(Root);
        }
        public TitlesViewController(RootElement root)
            : base(root)
        {
            Autorotate = true;
            HasNavigationBar = true;
            RefreshRequested += (sender, e) =>
            {
                NavigationController.PopViewControllerAnimated(true);
                ReloadComplete();
            };
        }

        private new void ReloadComplete()
        {
            base.XReloadComplete();
        }

        private void LoadData(RootElement root)
        {
            var sec1 = new Section("��ݷ�ʽ");
            foreach (var shortcut in Application.BusinessHelper.SelectShortcuts())
            {
                var item = shortcut;
                var element = CreateElement(item);
                sec1.Add(element);
            }
            root.Add(sec1);

            var sec2 = new Section("��Ŀ");
            var titles = Application.BusinessHelper.SelectTitles(new DbTitle());
            foreach (var t in titles)
            {
                var item = t;
                var element = CreateElement(item);
                sec2.Add(element);
            }
            root.Add(sec2);


            NavigationItem.SetRightBarButtonItem(
                                                 new UIBarButtonItem(
                                                     "+",
                                                     UIBarButtonItemStyle.Bordered,
                                                     (sender, e) =>
                                                     {
                                                         var v = new UIAlertView(
                                                             "����",
                                                             "�����ĸ���",
                                                             null,
                                                             "��ݷ�ʽ",
                                                             new[] {"��Ŀ"});
                                                         v.Clicked += (s, ee) =>
                                                                      {
                                                                          if (ee.ButtonIndex == 0)
                                                                          {
                                                                              var detail = new DbShortcut();
                                                                              var el = CreateElement(detail, sec1);
                                                                              NavigationController.PushViewController(
                                                                                                                      new TitlesViewController
                                                                                                                          (el),
                                                                                                                      true);
                                                                          }
                                                                          else
                                                                          {
                                                                              var detail = new DbTitle();
                                                                              var el = CreateElement(detail, sec2);
                                                                              NavigationController.PushViewController(
                                                                                                                      new TitlesViewController
                                                                                                                          (el),
                                                                                                                      true);
                                                                          }
                                                                      };
                                                         v.Show();
                                                     }),
                                                 false);
        }

        private RootElement CreateElement(DbShortcut item, Section itemsSection = null)
        {
            var idElement = new EntryElement("ID", "���", item.ID.AsID())
            {
                KeyboardType = UIKeyboardType.NumbersAndPunctuation
            };
            var nameElement = new EntryElement("����","����", item.Name);
            var pathElement = new EntryElement("·��", "б�ּܷ����ֺŲ���", item.Path);
            var element = new RootElement(item.Name)
                              {
                                  new Section
                                      {
                                          idElement,
                                          nameElement,
                                          pathElement
                                      }
                              };
            if (itemsSection != null)
            {
                element.Caption = "�¿�ݷ�ʽ";
                element.Add(
                            new Section("����")
                                {
                                    new ButtonElement(
                                        "����",
                                        () =>
                                        {
                                            int val;
                                            if (Int32.TryParse(idElement.Value, out val))
                                                item.ID = val;
                                            item.Name = nameElement.Value;
                                            item.Path = pathElement.Value;
                                            Application.BusinessHelper.InsertShortcut(item);
                                            element.Caption = item.Name;
                                            itemsSection.Add(element);
                                            NavigationController.PopViewControllerAnimated(true);
                                        })
                                });
            }
            else
            {
                element.Add(
                            new Section("����")
                                {
                                    new ButtonElement(
                                        "����",
                                        () =>
                                        {
                                            if (Application.BusinessHelper.DeleteShortcuts(item) != 0)
                                            {
                                                int val;
                                                if (Int32.TryParse(idElement.Value, out val))
                                                    item.ID = val;
                                                else
                                                    item.ID = null;
                                                item.Name = nameElement.Value;
                                                item.Path = pathElement.Value;
                                                Application.BusinessHelper.InsertShortcut(item);
                                                element.Caption = item.Name;
                                            }
                                            else
                                                (new UIAlertView("����", "û����ؼ�¼��", null, "ȷ��", null)).Show();
                                        }),
                                    new ButtonElement(
                                        "ɾ��",
                                        () =>
                                        {
                                            if (Application.BusinessHelper.DeleteShortcuts(item) != 0)
                                            {
                                                var section = element.Parent as Section;
                                                if (section != null)
                                                    section.Remove(element);
                                                NavigationController.PopViewControllerAnimated(true);
                                            }
                                            else
                                                (new UIAlertView("ɾ��", "û����ؼ�¼��", null, "ȷ��", null)).Show();
                                        })
                                });
            }
            return element;
        }

        private RootElement CreateElement(DbTitle item, Section itemsSection = null)
        {
            var idElement = new EntryElement("ID", "��Ŀ����", item.ID.AsTitle())
            {
                KeyboardType = UIKeyboardType.NumbersAndPunctuation
            };
            var nameElement = new EntryElement("����","����", item.Name);
            var hidElement = new EntryElement("�ϼ�ID", "��д��Ŀ����", item.H_ID.AsTitle())
            {
                KeyboardType = UIKeyboardType.NumbersAndPunctuation
            };
            var tlElement = new EntryElement("�㼶", "��0��ʼ", item.TLevel.ToString())
            {
                KeyboardType = UIKeyboardType.NumbersAndPunctuation,
                ReturnKeyType = UIReturnKeyType.Done
            };
            var element = new RootElement(GetCaption(item))
                              {
                                  new Section
                                      {
                                          idElement,
                                          nameElement,
                                          hidElement,
                                          tlElement
                                      }
                              };
            if (itemsSection != null)
            {
                element.Caption = "�¿�Ŀ";
                element.Add(
                            new Section("����")
                                {
                                    new ButtonElement(
                                        "����",
                                        () =>
                                        {
                                            item.ID = Convert.ToDecimal(idElement.Value);
                                            item.Name = nameElement.Value;
                                            item.H_ID = String.IsNullOrEmpty(hidElement.Value)
                                                            ? null
                                                            : (decimal?)Convert.ToDecimal(hidElement.Value);
                                            item.TLevel = Convert.ToInt32(tlElement.Value);
                                            Application.BusinessHelper.InsertTitle(item);
                                            element.Caption = GetCaption(item);
                                            itemsSection.Add(element);
                                            NavigationController.PopViewControllerAnimated(true);
                                        })
                                });
            }
            else
            {
                element.Add(
                            new Section("����")
                                {
                                    new ButtonElement(
                                        "����",
                                        () =>
                                        {
                                            Application.BusinessHelper.DeleteTitles(item);
                                            item.ID = Convert.ToDecimal(idElement.Value);
                                            item.Name = nameElement.Value;
                                            item.H_ID = String.IsNullOrEmpty(hidElement.Value)
                                                            ? null
                                                            : (decimal?)Convert.ToDecimal(hidElement.Value);
                                            item.TLevel = Convert.ToInt32(tlElement.Value);
                                            Application.BusinessHelper.InsertTitle(item);
                                            element.Caption = GetCaption(item);
                                        }),
                                    new ButtonElement(
                                        "ɾ��",
                                        () =>
                                        {
                                            Application.BusinessHelper.DeleteTitles(item);
                                            var section = element.Parent as Section;
                                            if (section != null)
                                                section.Remove(element);
                                            NavigationController.PopViewControllerAnimated(true);
                                        })
                                });
            }
            return element;
        }

        private string GetCaption(DbTitle item) { return String.Format("{0} {1}", item.ID.AsTitle(), item.Name); }
    }
}