using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace ProfessionalAccounting
{
    public class Network
    {
        public void Begin()
        {
            var client = new TcpClient();
            client.BeginConnect(IPAddress.Parse("192.168.1.100"), 14285, new AsyncCallback(ConnectCallback), client);
        }

        private void ConnectCallback(IAsyncResult ar)
        {
            var t = (TcpClient)ar.AsyncState;
            try
            {
                if (t.Connected)
                {
                    //SEND DATA
                    t.EndConnect(ar);
                }
            }
            catch { }
        }

        private void ExchangeData(TcpClient client)
        {
            var stream = client.GetStream();
            var buffSend = Encoding.UTF8.GetBytes("Hello World");
            stream.BeginWrite(buffSend, 0, buffSend.Length, new AsyncCallback(ar => { }), stream);
            
            var buffRead = new byte[client.Available];
            try
            {
                stream.BeginRead(buffRead, 0, buffRead.Length, new AsyncCallback(ar => { }), stream);
            }
            catch { }
        }
    }
}