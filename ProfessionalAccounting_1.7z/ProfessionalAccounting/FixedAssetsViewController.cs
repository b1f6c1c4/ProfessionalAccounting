using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.BLL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting
{
    class FixedAssetsViewController : DialogViewController
    {
        public FixedAssetsViewController() : base(new RootElement("�̶��ʲ�"), true) {}

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            var sec=new Section();
            foreach (var fixedAsset in Application.BusinessHelper.SelectFixedAssets(new DbFixedAsset()))
            {
                Application.BusinessHelper.GetFixedAssetDetail(fixedAsset);
                sec.Add(CreatElement(fixedAsset));
            }
            Root.Add(sec);
        }


        public RootElement CreatElement(DbFixedAsset entity, Section faSection =null)
        {
            var idElement = new EntryElement("ID", "Ψһ��ʶ��", entity.ID);
            var nameElement = new EntryElement("����", "", entity.Name);
            var valueElement = new EntryElement("ԭֵ", "�����Ԫ", entity.Value.AsCurrency());
            var dtElement = new DateElement("��������", entity.DT ?? DateTime.Now.Date);
            var dlifeElement = new EntryElement("�۾�����", "��", entity.DepreciableLife.ToString());
            var titleElement = new EntryElement("������Ŀ", "�۾ɷ��ü���Ŀ�Ŀ", entity.Title.AsTitle());
            var r = new RootElement(entity.Name)
                        {
                            new Section("������Ϣ")
                                {
                                    idElement,
                                    nameElement,
                                    valueElement,
                                    new StringElement("�����ֵ", entity.XValue.AsCurrency())
                                },
                            new Section("�۾�")
                                {
                                    dtElement,
                                    dlifeElement,
                                    new StringElement("�����۾�", entity.DepreciatedValue1.AsCurrency()),
                                    titleElement
                                },
                            new Section("��ֵ")
                                {
                                    new StringElement("�����ֵ׼��", entity.DepreciatedValue2.AsCurrency())
                                }
                        };
            if (faSection == null)
                r.Add(
                      new Section("����")
                          {
                              new ButtonElement(
                                  "����",
                                  () =>
                                  {
                                      Application.BusinessHelper.DeleteFixedAssets(entity);
                                      entity.ID = idElement.Value;
                                      entity.Name = nameElement.Value;
                                      entity.DT = dtElement.DateValue.ToLocalTime();
                                      entity.DepreciableLife = Convert.ToInt32(dlifeElement.Value);
                                      entity.Title = Convert.ToDecimal(titleElement.Value);
                                      Application.BusinessHelper.InsertFixedAsset(entity);

                                      //TODO:��ʾ��Ҫ�ؽ��۾�

                                      r.Caption = entity.Name;
                                      Title = r.Caption;
                                  }),
                              new ButtonElement(
                                  "ɾ��",
                                  () =>
                                  {
                                      //TODO:��ʾ��Ҫ�ؽ��۾�
                                      var dbFixedAsset = new DbFixedAsset {ID = entity.ID};
                                      var cnt =
                                          Application.BusinessHelper.SelectFixedAssets(dbFixedAsset).Count();
                                      var v = new UIAlertView(
                                          "ɾ��",
                                          String.Format("��ȷ��ɾ��{0}����¼��", cnt),
                                          null,
                                          "ȡ��",
                                          new[] {"ȷ��"});
                                      v.Clicked += (sender, e) =>
                                                   {
                                                       if (e.ButtonIndex == 1)
                                                           Application.BusinessHelper.SelectFixedAssets(dbFixedAsset);
                                                       var section = r.Parent as Section;
                                                       if (section != null)
                                                           section.Remove(r);
                                                       NavigationController.PopViewControllerAnimated(true);
                                                   };
                                      v.Show();
                                  })
                          });
            else
                r.Add(
                      new Section("����")
                          {
                              new ButtonElement(
                                  "����",
                                  () =>
                                  {
                                      entity.ID = idElement.Value;
                                      entity.Name = nameElement.Value;
                                      entity.DT = dtElement.DateValue.ToLocalTime();
                                      entity.DepreciableLife = Convert.ToInt32(dlifeElement.Value);
                                      entity.Title = Convert.ToDecimal(titleElement.Value);
                                      Application.BusinessHelper.InsertFixedAsset(entity);

                                      //TODO:��ʾ��Ҫ�ؽ��۾�

                                      r.Caption = entity.Name;
                                      Title = r.Caption;
                                  }),
                              new ButtonElement(
                                  "�������Ψһ��ʶ��",
                                  () => idElement.Value = Application.BusinessHelper.GenerateUniqueIdentifier())
                          });
            return r;
        }
    }
}