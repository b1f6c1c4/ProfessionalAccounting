using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MonoTouch.Dialog;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace ProfessionalAccounting
{

    public class ButtonElement : StyledStringElement
    {
        public ButtonElement(string caption, NSAction tapped) : base(caption, tapped) { TextColor = UIColor.FromRGB(0, 122, 255); }
    }
}