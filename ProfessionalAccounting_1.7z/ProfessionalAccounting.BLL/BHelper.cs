﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using MonoTouch.UIKit;
using ProfessionalAccounting.DAL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting.BLL
{
    public class BHelper
    {
        public const decimal FullYearProfit = (decimal)4103.00;
        public const decimal FixedAsset = (decimal)1601.00;
        public const decimal FixedAssetDepreciation = (decimal)1602.00;
        public const decimal FixedAssetImpairment = (decimal)1603.00;
        public const decimal Cost = (decimal)5000.00;

        private IDbHelper m_Db;
        private string m_DbName;

        private Dictionary<decimal, string> m_Titles;

        public void Connect(string fn)
        {
            m_Db = new SqliteDbHelper(fn);
            m_DbName = fn;
            GetTitles();
        }

        public void Disconnect()
        {
            m_Db.Dispose();
            m_Db = null;
        }

        public bool IsCarry(DbItem entity)
        {
            return m_Db.SelectDetails(entity).Any(d => d.Title == FullYearProfit);
        }

        public decimal IsBalanced(DbItem entity)
        {
            // ReSharper disable once PossibleInvalidOperationException
            return m_Db.SelectDetails(new DbDetail {Remark = entity.ID.ToString()}).Sum(d => d.Fund.Value);
        }

        public decimal GetBalance(DbTitle title, string remark = null, DateTime? dt = null)
        {
            var lstx = m_Db.SelectItems(new DbItem());
            if (dt.HasValue)
                lstx = lstx.Where(i => i.DT <= dt);
            var lst = lstx.Select(i => i.ID);
            title.Balance = m_Db.SelectDetails(new DbDetail {Title = title.ID, Remark = remark})
                                .Where(d => lst.Contains(d.Item))
                                .Sum(d => d.Fund.Value);
            return title.Balance.Value;
        }

        public decimal GetABalance(DbTitle entity)
        {
            entity.ABalance = GetBalance(entity);
            foreach (var t in m_Db.SelectTitles(new DbTitle { H_ID = entity.ID }))
                entity.ABalance += GetABalance(t);
            return entity.ABalance.Value;
        }
        private decimal GetABalance(DbTitle entity, ref IList<DbTitle> titles)
        {
            entity.ABalance = GetBalance(entity);
            foreach (var t in m_Db.SelectTitles(new DbTitle {H_ID = entity.ID}))
                entity.ABalance += GetABalance(t, ref titles);
            return entity.ABalance.Value;
        }
        public decimal GetABalance(DbTitle entity, out List<DbTitle> titles, bool cascadeReturn)
        {
            entity.ABalance = GetBalance(entity);
            IList<DbTitle> tl = new List<DbTitle>();
            foreach (var t in m_Db.SelectTitles(new DbTitle {H_ID = entity.ID}))
            {
                tl.Add(t);
                if (cascadeReturn)
                    entity.ABalance += GetABalance(t, ref tl);
                else
                    entity.ABalance += GetABalance(t);
            }
            titles = tl as List<DbTitle>;
            return entity.ABalance.Value;
        }

        public IEnumerable<DbDetail> GetXBalances(DbTitle entity, bool withZero)
        {
            var lst = m_Db.GetXBalances(new DbDetail { Title = entity.ID });
            return withZero ? lst : lst.Where(d => d.Fund != 0);
        }
        public DbDetail GetXBalances(DbDetail entity)
        {
            var lst = m_Db.GetXBalances(entity);
            return lst.Single();
        }

        private void GetTitles()
        {
            m_Titles = new Dictionary<decimal, string>();
            foreach (var title in m_Db.SelectTitles(new DbTitle()))
                if (title.ID != null)
                    m_Titles.Add(title.ID.Value, title.Name);
        }
        
        public string GetTitleName(decimal? id)
        {
            if (id.HasValue)
                if (m_Titles.ContainsKey(id.Value))
                    return m_Titles[id.Value];
            return null;
        }

        public decimal Carry(DateTime? date)
        {
            var dt = date ?? DateTime.Now.Date;
            var cnt = (decimal)0;
            // ReSharper disable once PossibleInvalidOperationException
            var lst = m_Db.SelectTitles(new DbTitle()).Where(t => IsToCarry(t.ID.Value));
            var titles = lst as IList<DbTitle> ?? lst.ToList();
            if (!titles.Any())
                return 0;
            var item = new DbItem { DT = dt };
            foreach (var t in titles)
            {
                var b = GetBalance(t, null, dt);
                m_Db.InsertDetail(new DbDetail {Item = item.ID, Title = t.ID, Fund = -b});
                cnt += b;
            }
            m_Db.InsertDetail(new DbDetail {Item = item.ID, Title = FullYearProfit, Fund = cnt});
            return cnt;
        }

        private static bool IsToCarry(decimal id) { return id >= Cost; }

        public decimal Depreciate(DateTime? date, DepreciationMethod method)
        {
            var dt = date ?? DateTime.Now.Date;
            var dlst=new Dictionary<decimal,decimal>();
            var item = new DbItem { DT = dt };
            foreach (var fa in m_Db.SelectFixedAssets(new DbFixedAsset()))
            {
                var v = FixedAssetHelper.Depreciate(fa,12,dt.SubtractMonth(fa.DT.Value), method);
                m_Db.InsertDetail(
                                  new DbDetail
                                      {
                                          Item = item.ID,
                                          Title = FixedAssetDepreciation,
                                          Remark = fa.ID.ToString(),
                                          Fund = -v
                                      });
                // ReSharper disable once AssignNullToNotNullAttribute
                // ReSharper disable once PossibleInvalidOperationException
                if (dlst.ContainsKey(fa.Title.Value))
                    dlst[fa.Title.Value] += v;
                else
                    dlst[fa.Title.Value] = v;
            }
            var cnt = (decimal)0;
            foreach (var kvp in dlst)
            {
                m_Db.InsertDetail(new DbDetail {Item = item.ID, Title = kvp.Key, Fund = kvp.Value});
                cnt += kvp.Value;
            }
            return cnt;
        }

        public void RebuildDepreciate(DateTime? origDate = null)
        {
            var dt = origDate ?? new DateTime(2014, 1, 1); // TODO: Get OrigDate
            
        }

        public IEnumerable<DbTitle> SelectTitles(DbTitle entity) { return m_Db.SelectTitles(entity); }
        public int SelectItemsCount(DbItem entity) { return m_Db.SelectItemsCount(entity); }
        public IEnumerable<DbItem> SelectItems(DbItem entity) { return m_Db.SelectItems(entity); }
        public IEnumerable<DbDetail> SelectDetails(DbItem entity) { return m_Db.SelectDetails(entity); }
        public IEnumerable<DbDetail> SelectDetails(DbDetail entity) { return m_Db.SelectDetails(entity); }
        public int SelectDetailsCount(DbDetail entity) { return m_Db.SelectDetailsCount(entity); }
        public IEnumerable<DbFixedAsset> SelectFixedAssets(DbFixedAsset entity) { return m_Db.SelectFixedAssets(entity); }

        public IEnumerable<DbShortcut> SelectShortcuts()
        {
            foreach (var shortcut in m_Db.SelectShortcuts(new DbShortcut()))
            {
                var xpath = Regex.Split(shortcut.Path, @",(?=(?:[^']*'[^']*')*[^']*$)");
                shortcut.Balance = 0;
                foreach (var path in xpath)
                {
                    var paths = path.Split(new[] { '/' });
                    if (paths.Last().StartsWith("T"))
                        shortcut.Balance += GetABalance(new DbTitle {ID = Convert.ToDecimal(paths.Last().Substring(1))});
                    if (paths.Last().StartsWith("R"))
                        shortcut.Balance +=
                            GetXBalances(
                                         new DbDetail
                                             {
                                                 Title = Convert.ToDecimal(paths[paths.Length - 2].Substring(1)),
                                                 Remark = paths.Last().Substring(2, paths.Last().Length - 3)
                                             }).Fund;
                }
                yield return shortcut;
            }
        }

        public bool InsertItem(DbItem item)
        {
            if (item.ID.HasValue)
                if (m_Db.SelectItems(new DbItem { ID = item.ID }).Any())
                    m_Db.DeltaItemsFrom(item.ID.Value);
            return m_Db.InsertItem(item);
        }
        public bool InsertItem(DbItem item, IEnumerable<DbDetail> details)
        {
            if (!InsertItem(item))
                return false;
            var flag = true;
            foreach (var detail in details)
            {
                detail.Item = item.ID;
                flag &= m_Db.InsertDetail(detail);
            }
            return flag;
        }

        public bool InsertDetail(DbDetail entity) { return m_Db.InsertDetail(entity); }

        public int DeleteItems(DbItem entity)
        {
            var count = 0;
            foreach (var i in m_Db.SelectItems(entity))
            {
                count += m_Db.DeleteItems(new DbItem {ID = i.ID});
                m_Db.SelectDetails(i);
            }
            return count;
        }
        public int DeleteDetails(DbDetail entity) { return m_Db.DeleteDetails(entity); }

        public bool InsertFixedAsset(DbFixedAsset entity) { return m_Db.InsertFixedAsset(entity); }
        public int DeleteFixedAssets(DbFixedAsset entity) { return m_Db.DeleteFixedAssets(entity); }

        public bool InsertShortcut(DbShortcut entity) { return m_Db.InsertShortcuts(entity); }
        public int DeleteShortcuts(DbShortcut entity) { return m_Db.DeleteShortcuts(new DbShortcut {ID = entity.ID}); }


        public bool InsertTitle(DbTitle entity) { return m_Db.InsertTitle(entity); }
        public int DeleteTitles(DbTitle entity) { return m_Db.DeleteTitles(entity); }

        public void Shrink(DbItem item)
        {
            var lst = m_Db.SelectDetails(item)
                          .GroupBy(
                                   d => new DbDetail {Title = d.Title, Remark = d.Remark},
                                   (key, grp) =>
                                   {
                                       key.Item = item.ID;
                                       key.Fund =
                                           grp.Sum(
                                                   d =>
                                                   d.Fund);
                                       return key;
                                   });
            m_Db.DeleteDetails(item);
            foreach (var detail in lst)
                m_Db.InsertDetail(detail);
        }

        public void GetFixedAssetDetail(DbFixedAsset entity, DateTime? dt = null)
        {
            var fa = GetBalance(new DbTitle { ID = FixedAsset }, entity.ID, dt);
            var faD = GetBalance(new DbTitle { ID = FixedAssetDepreciation }, entity.ID, dt);
            var faI = GetBalance(new DbTitle { ID = FixedAssetImpairment }, entity.ID, dt);
            entity.DepreciatedValue1 = -faD;
            entity.DepreciatedValue2 = -faI;
            entity.XValue = fa + faD + faI;
        }

        public string GenerateUniqueIdentifier(bool toPasteBoard = true)
        {
            /*var rand = new Random();
            var buff = new byte[4];
            rand.NextBytes(buff);
            var sb = new StringBuilder();
            foreach (var b in buff)
                sb.AppendFormat("{0:X2}", b);
            if (toPasteBoard)
                UIPasteboard.General.String = sb.ToString();
            return sb.ToString();*/
            var guid = Guid.NewGuid();
            if (toPasteBoard)
                UIPasteboard.General.String = guid.ToString();
            return guid.ToString().ToUpperInvariant();
        }

    }
}
