using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MonoTouch.Foundation;
using MonoTouch.UIKit;
using ProfessionalAccounting.DAL;
using ProfessionalAccounting.Entities;

namespace ProfessionalAccounting.BLL
{
    public enum DepreciationMethod
    {
        Linear=0/*,
        Double=1,
        Total=2*/
    }

    public static class FixedAssetHelper
    {
        public static decimal Depreciate(DbFixedAsset entity, int grouped ,int already,DepreciationMethod method)
        {
            var toDepValue = entity.XValue.Value - entity.Salvge.Value;
            var toDepTime = entity.DepreciableLife.Value - already;
            var fullGroups = toDepTime / grouped;
            if (toDepTime == 1)
                return toDepValue;
            switch (method)
            {
                case DepreciationMethod.Linear:
                    return toDepValue / toDepTime;
                /*case DepreciationMethod.Double:
                    if (toDepTime <= 2 * grouped)
                        return toDepValue / (2 * grouped);
                    var rate = 2.0 *grouped / toDepTime;
                    var xid = already / grouped;
                    var r = Math.Pow(rate, xid);*/
            }
            return 0;
        }

        public static decimal Depreciate(DbFixedAsset entity, int grouped, int already, int delta,
                                         DepreciationMethod method)
        {
            var count = (decimal)0;
            for (var i = 0; i < delta; i++)
            {
                count += Depreciate(entity, grouped, already + i, method);
            }
            return count;
        }
    }
}