﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TcpDemo
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            Listen();
        }
        /// <summary>
        /// 监听TCP连接
        /// </summary>
        public void Listen()
        {
            var listener = new TcpListener(new IPEndPoint(IPAddress.Any, 14285));
            listener.Start();
            var taskMain = Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    var tc = listener.AcceptTcpClient();
                    var stream = tc.GetStream();
                    while (!stream.DataAvailable) {}
                    using (var r = new StreamReader(stream, Encoding.UTF8))
                    {
                        var sx = r.ReadToEnd();
                        textBox2.Text = sx;
                    }
                }
            }, TaskCreationOptions.LongRunning);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var tcpClnt = new TcpClient("127.0.0.1", 14285);
            //Checking socket is connected or not.
            //====================================
            if (tcpClnt.Connected)
            {
                var networkStrm = tcpClnt.GetStream();
                var streamRdr = new StreamReader(networkStrm);
                var streamWtr = new StreamWriter(networkStrm,Encoding.UTF8);
                streamWtr.WriteLine(textBox1.Text);
                streamWtr.Flush();

                networkStrm.Close();
                tcpClnt.Close();
            }
        }
    }
}
