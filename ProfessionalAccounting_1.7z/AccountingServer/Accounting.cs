﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Threading;

namespace AccountingServer
{
    public partial class Accounting : ServiceBase
    {
        private string m_ClientReq;
        private Thread m_Thread;

        private NetworkStream m_Stream; //Creating a Network Stream
        private Socket m_Socket; //Creating a Socket

        private StreamReader m_Reader; //Creating a Stream reader

        private StreamWriter m_Writer; //Creating a Stream Writer
        private TcpListener m_Listener; //TCP Listner for Socket

        protected Accounting()
        {
            InitializeComponent();

            if (!EventLog.SourceExists("AccountingLogSource"))
                EventLog.CreateEventSource("AccountingLogSource", "AccountingSourceLog");

            //Name of EventLog
            eventLog.Source = "AccountingLogSource";
            eventLog.Log = "AccountingSourceLog";
        }

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        static void Main()
        {
            var servicesToRun = new ServiceBase[] 
                                              { 
                                                  new Accounting() 
                                              };
            Run(servicesToRun);
        }

        protected override void OnStart(string[] args)
        {
            m_Listener = new TcpListener(new IPEndPoint(IPAddress.Any, 14285));
            eventLog.WriteEntry("AccountingServerService started");
            m_Thread = new Thread(ThreadFunction) {IsBackground = true};
            //m_Thread.Start();
        }

        protected override void OnStop()
        {
            eventLog.WriteEntry("AccountingServerService stopped");
            //m_Thread.Abort();
        }

        /// <summary>
        ///     Continue this service.
        /// </summary>
        protected override void OnContinue()
        {
            eventLog.WriteEntry("AccountingServerService is continuing in working");
        }

        /// <summary>
        ///     For Listening Socket.
        /// </summary>
        public void ThreadFunction()
        {
            m_Listener.Start(4);
            while (true)
            {
                m_Socket = m_Listener.AcceptSocket();
                eventLog.WriteEntry("Client Respose Received");
                try
                {
                    if (m_Socket.Connected)
                    {
                        try
                        {
                            m_Stream = new NetworkStream(m_Socket);
                            m_Reader = new StreamReader(m_Stream);
                            m_Writer = new StreamWriter(m_Stream);
                            m_ClientReq = m_Reader.ReadToEnd();
                        }
                        catch (OutOfMemoryException ex)
                        {
                            eventLog.WriteEntry("Problem occur while reading stream:-" + ex.Message);
                            eventLog.WriteEntry("AccountingServerService is Stopping");
                            OnStop();
                        }
                        catch (IOException ex)
                        {
                            eventLog.WriteEntry("Problem occur while intializing network stream:-" + ex.Message);
                            eventLog.WriteEntry("AccountingServerService is Stoping");
                            OnStop();
                        }
                        eventLog.WriteEntry("Current Command:" + m_ClientReq);
                    }
                }
                catch (IOException ex)
                {
                    eventLog.WriteEntry("Exception occur in the service:-" + ex.Message);
                    m_Writer.WriteLine("Stop");
                }
                try
                {
                    m_Writer.Close();
                    m_Reader.Close();
                    m_Stream.Close();
                    m_Socket.Close();
                    m_ClientReq = null;
                    eventLog.WriteEntry("Request completed");
                }
                catch (IOException ex)
                {
                    eventLog.WriteEntry("Problem occur while closing the socket:-" + ex.Message);
                    eventLog.WriteEntry("AccountingServerService is Stoping");
                    OnStop();
                }
            }
        }
    }
}
